# ResTagDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **number** |  | [default to undefined]
**nome** | **string** |  | [default to undefined]

## Example

```typescript
import { ResTagDTO } from './api';

const instance: ResTagDTO = {
    id,
    nome,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
