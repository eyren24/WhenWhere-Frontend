# FiltriAgendaDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**titolo** | **string** |  | [optional] [default to undefined]
**tagId** | **number** |  | [optional] [default to undefined]

## Example

```typescript
import { FiltriAgendaDTO } from './api';

const instance: FiltriAgendaDTO = {
    titolo,
    tagId,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
