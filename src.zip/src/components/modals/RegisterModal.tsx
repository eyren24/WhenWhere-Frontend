import '../../assets/css/modals/login.css';
import React, {useState} from 'react';
import toast from "react-hot-toast";
import {useAuthStore} from "../../stores/AuthStore.ts";
import {useNavigate} from "react-router";
import {ClipLoader} from "react-spinners";

export const RegisterModal = ({show, onClose}: { show: boolean; onClose: () => void }) => {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [birthDate, setBirthDate] = useState('');
    const [gender, setGender] = useState('');

    const {isLoading, signup} = useAuthStore();
    const navigate = useNavigate();

    const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
        e.preventDefault();
        if (!firstName || !lastName || !email || !password || !confirmPassword || !birthDate || !gender) {
            toast.error("Tutti i campi sono obbligatori");
            return;
        }

        if (password !== confirmPassword) {
            toast.error("Le password non coincidono");
            return;
        }

        await signup({
            email,
            password,
            nome: firstName,
            cognome: lastName,
            dataNascita: birthDate,
            genere: gender,
            confermaPassword: confirmPassword
        }).then((res) => {
            if (res.success) {
                toast.success('Registrazione completata con successo!');
                navigate('/areaPersonale');
            }
        }).catch((err) => {
            toast.error(err || 'Errore durante la registrazione');
        });
        onClose();
    };

    return (
        <>{show &&
            <div className="login-modal-wrapper">
                <div className="overlay" onClick={onClose}/>
                <form onSubmit={handleSubmit} className="register-wrapper">
                    <div className="register-header">
                        <h2>Registrazione</h2>
                    </div>
                    <div className="register-body">
                        {/* Prima riga: Nome, Cognome */}
                        <div className="register-form-row">
                            <div className="register-form-column">
                                <label htmlFor="firstName">Nome</label>
                                <input
                                    id="firstName"
                                    type="text"
                                    placeholder="Inserisci il nome"
                                    value={firstName}
                                    onChange={(e) => setFirstName(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="register-form-column">
                                <label htmlFor="lastName">Cognome</label>
                                <input
                                    id="lastName"
                                    type="text"
                                    placeholder="Inserisci il cognome"
                                    value={lastName}
                                    onChange={(e) => setLastName(e.target.value)}
                                    required
                                />
                            </div>
                        </div>

                        {/* Seconda riga: Genere, Data di nascita */}
                        <div className="register-form-row">
                            <div className="register-form-column">
                                <label htmlFor="gender">Genere</label>
                                <select
                                    id="gender"
                                    value={gender}
                                    onChange={(e) => setGender(e.target.value)}
                                    required
                                >
                                    <option value="">Seleziona il genere</option>
                                    <option value="maschio">Maschio</option>
                                    <option value="femmina">Femmina</option>
                                    <option value="altro">Altro</option>
                                </select>
                            </div>
                            <div className="register-form-column">
                                <label htmlFor="birthDate">Data di nascita</label>
                                <input
                                    id="birthDate"
                                    type="date"
                                    value={birthDate}
                                    onChange={(e) => setBirthDate(e.target.value)}
                                    required
                                />
                            </div>
                        </div>

                        {/* Spazio / separazione */}
                        <div style={{height: "10px"}}/>

                        {/* Terza riga: Email (singola colonna piena) */}
                        <div className="register-form-full">
                            <label htmlFor="email">Email</label>
                            <input
                                id="email"
                                type="email"
                                placeholder="Inserisci l'email"
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                required
                            />
                        </div>

                        {/* Quarta riga: Password + Conferma */}
                        <div className="register-form-row">
                            <div className="register-form-column">
                                <label htmlFor="password">Password</label>
                                <input
                                    id="password"
                                    type="password"
                                    placeholder="Inserisci la password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="register-form-column">
                                <label htmlFor="confirmPassword">Conferma Password</label>
                                <input
                                    id="confirmPassword"
                                    type="password"
                                    placeholder="Conferma la password"
                                    value={confirmPassword}
                                    onChange={(e) => setConfirmPassword(e.target.value)}
                                    required
                                />
                            </div>
                        </div>
                    </div>
                    <div className="register-footer">
                        <button type="submit" className="register-button-full">{isLoading ?
                            <ClipLoader/> : 'Registrati'}</button>
                    </div>
                </form>
            </div>
        }
        </>
    );
};
