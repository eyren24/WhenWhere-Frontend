# ReqUpdateTagDTO


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**nome** | **string** |  | [default to undefined]

## Example

```typescript
import { ReqUpdateTagDTO } from './api';

const instance: ReqUpdateTagDTO = {
    nome,
};
```

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)
